deviceObj = icdevice('matlab_rsscope_driver.mdd','TCPIP0::192.168.1.5::inst0::INSTR');
pause(5);
 connect(deviceObj);
 pause(3);
 groupObj = get(deviceObj, 'Configuration');%%�]�� autoset �b "Configuration" �Ҷ��~���\��
 numberObj = get(deviceObj, 'configurationacquisition');
 rateObj = get(deviceObj, 'Configurationacquisition');
 historyObj = get(deviceObj, 'configurationdisplayhistory');
 dataObj = get(deviceObj, 'utilitydatamanagementwaveformexport');
 triggerObj = get(deviceObj, 'Configurationtrigger');
 errorObj = get(deviceObj, 'Utility');
  sampleObj = get(deviceObj, 'configurationconfigurationinformation');
  fileObj = get(deviceObj, 'utilitydatamanagementlongtermandmeashistogramsexport');
  file2Obj = get(deviceObj, 'utilitydatamanagementwaveformexport');
  channelObj= get(deviceObj, 'configurationchannel');
  error2Obj= get(deviceObj, 'utilityerrorinfo');
  description = zeros (256,1);%%�s�񪬺A��
    Ans=1;
  pause(3);